exports.passwordReset = function (event, context, callback){ console.log('Test'); callback(null); }
